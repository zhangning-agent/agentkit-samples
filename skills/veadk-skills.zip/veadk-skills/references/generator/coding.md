# 代码生成

请你根据如下的说明，来基于上述生成的内容，构建生成 Python 代码。具体的 VeADK 代码生成规则你可以参考：

- **Agent 部分**：references/common/agent.md
- **工具部分**：references/common/tools.md
